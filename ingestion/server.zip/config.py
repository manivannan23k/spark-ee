import json

all_config = json.load(open("config.json"))
config = all_config["hostel"]
# 103.67.235.120
